// .vuepress/theme/index.js
module.exports = {
    extend: '@vuepress/theme-default'
}
