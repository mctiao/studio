export default [
  "",
  {
    title: "学习路线",
    collapsable: false,
    children: [
      "Java学习路线 by 程序员鱼皮.md",
      "前端学习路线 by 程序员鱼皮.md",
      "C++学习路线 by 程序员鱼皮.md",
      "Python学习路线 by 程序员鱼皮.md",
      "数据结构和算法学习路线 by 程序员鱼皮.md",
      "SQL免费实战自学网站 by 程序员鱼皮.md",
      "计算机基础学习路线 by 程序员鱼皮.md",
      "Git&GitHub学习路线 by 程序员鱼皮.md",
      "设计模式学习路线 by 程序员鱼皮.md",
      "Linux学习路线 by 程序员鱼皮.md",
    ],
  },
];
